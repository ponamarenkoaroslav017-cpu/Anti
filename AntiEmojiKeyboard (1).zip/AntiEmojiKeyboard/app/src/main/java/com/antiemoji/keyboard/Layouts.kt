package com.antiemoji.keyboard

/** Действия клавиш. */
enum class Act { CHAR, SHIFT, DEL, SYMS, ABC, LANG, SPACE, ENTER }

class Key(
    val label: String,
    val act: Act = Act.CHAR,
    val weight: Float = 1f,
    val alts: List<String> = emptyList(),
    val hideable: Boolean = false,
    val id: String = label
)

object Layouts {

    // Странные символы для зажатия. Намеренно без символов, которые рисуются как цветные эмодзи.
    private const val POOL =
        "★☆♪♫✓✗∞≈≠±√∑πΩμ€£¥₽₴§¶†‡•°‰«»„“”‹›¿¡…←→↑↓∂∆∏∫≤≥∈∩∪⊕⊗♭♯¤¢₿฿₩₹¦¬∴∵∝∅∇⌘⌥"

    private val ruRows = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

    private fun altsFor(lang: String, ch: Char, index: Int, topRow: Boolean, topIdx: Int): List<String> {
        val out = ArrayList<String>()
        if (topRow) out.add(((topIdx + 1) % 10).toString())
        if (lang == "ru") {
            if (ch == 'е') out.add("ё")
            if (ch == 'ь') out.add("ъ")
        }
        val n = POOL.length
        for (k in 0 until 3) out.add(POOL[(index * 3 + k) % n].toString())
        return out
    }

    fun numberRow(): List<Key> {
        val digits = "1234567890"
        val sup = listOf("½", "⅓", "¼", "²", "³", "⁴", "⅕", "⅞", "⁹", "°")
        return digits.mapIndexed { i, ch -> Key(ch.toString(), alts = listOf(sup[i])) }
    }

    fun letterRows(lang: String): List<List<Key>> {
        val rows = if (lang == "ru") ruRows else enRows
        var idx = 0
        val result = ArrayList<List<Key>>()
        for ((r, row) in rows.withIndex()) {
            val keys = ArrayList<Key>()
            if (r == 2) keys.add(Key("shift", Act.SHIFT, 1.4f))
            for ((i, ch) in row.withIndex()) {
                keys.add(
                    Key(
                        label = ch.toString().uppercase(),
                        alts = altsFor(lang, ch, idx, r == 0, i),
                        hideable = true,
                        id = "$lang:$ch"
                    )
                )
                idx++
            }
            if (r == 2) keys.add(Key("del", Act.DEL, 1.4f))
            result.add(keys)
        }
        return result
    }

    fun bottomRow(lang: String): List<Key> = listOf(
        Key("!#1", Act.SYMS, 1.3f),
        Key("lang", Act.LANG, 1f),
        Key(",", alts = listOf("-", "'", "\"", ";"), hideable = true, id = "comma"),
        Key(if (lang == "ru") "Русский" else "English", Act.SPACE, 4.2f),
        Key(".", alts = listOf("!", "?", ":", "…", ";"), hideable = true, id = "dot"),
        Key("enter", Act.ENTER, 1.3f)
    )

    fun symbolRows(): List<List<Key>> {
        val r1 = "@#$%&-+()/".map { Key(it.toString(), alts = listOf(altOf(it))) }
        val r2 = "*\"':;!?_=<".map { Key(it.toString(), alts = listOf(altOf(it))) }
        val r3 = ArrayList<Key>()
        r3.addAll(">[]{}\\|~^".map { Key(it.toString(), alts = listOf(altOf(it))) })
        r3.add(Key("del", Act.DEL, 1.4f))
        return listOf(r1, r2, r3)
    }

    fun symbolBottom(): List<Key> = listOf(
        Key("АБВ", Act.ABC, 1.3f),
        Key("lang", Act.LANG, 1f),
        Key(",", alts = emptyList()),
        Key("Пробел", Act.SPACE, 4.2f),
        Key(".", alts = emptyList()),
        Key("enter", Act.ENTER, 1.3f)
    )

    private fun altOf(c: Char): String = when (c) {
        '@' -> "©"
        '#' -> "№"
        '$' -> "€"
        '%' -> "‰"
        '&' -> "§"
        '-' -> "–"
        '+' -> "±"
        '(' -> "["
        ')' -> "]"
        '/' -> "÷"
        '*' -> "×"
        '"' -> "«"
        '\'' -> "»"
        ':' -> "∶"
        ';' -> "⁏"
        '!' -> "¡"
        '?' -> "¿"
        '_' -> "‾"
        '=' -> "≈"
        '<' -> "≤"
        '>' -> "≥"
        else -> "•"
    }
}
