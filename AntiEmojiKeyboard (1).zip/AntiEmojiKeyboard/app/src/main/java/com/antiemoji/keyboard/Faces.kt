package com.antiemoji.keyboard

/**
 * Лица собираются из нарисованных вручную частей: голова + глаза + рот + деталь.
 * 4 головы x 6 деталей x 8 пар глаз x 12 ртов = 2304 разных лица.
 */
object Faces {

    private val heads = listOf(
        Triple("face", "Лица", c(12f, 12f, 9f)),
        Triple("cat", "Коты", c(12f, 12f, 9f) + "M4.500 7.500L4 2.500l4.500 2.500 M19.500 7.500L20 2.500l-4.500 2.500"),
        Triple("bear", "Мишки", c(12f, 12f, 9f) + c(5f, 4.500f, 2.200f) + c(19f, 4.500f, 2.200f)),
        Triple(
            "bot", "Роботы",
            "M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z M12 4V1.500 M12 1.500v.01"
        )
    )

    private val eyes = listOf(
        "dots" to "M8.5 10v.01 M15.5 10v.01",
        "happy" to "M7 10.5q1.5-2 3 0 M14 10.5q1.5-2 3 0",
        "line" to "M7 10h3 M14 10h3",
        "round" to c(8.5f, 9.5f, 1.4f) + c(15.5f, 9.5f, 1.4f),
        "cross" to "M7 8.500l3 3 M10 8.500l-3 3 M14 8.500l3 3 M17 8.500l-3 3",
        "wink" to "M7 10.5q1.5-2 3 0 M15.5 10v.01",
        "sleepy" to "M7 9.500q1.500 2 3 0 M14 9.500q1.500 2 3 0",
        "spark" to "M8.5 7.500v4 M6.500 9.500h4 M15.500 7.500v4 M13.500 9.500h4"
    )

    private val mouths = listOf(
        "smile" to "M8 14.5q4 4.5 8 0",
        "grin" to "M8 14h8q0 4-4 4t-4-4z",
        "flat" to "M9 16h6",
        "frown" to "M8.5 17q3.5-3.5 7 0",
        "oh" to c(12f, 16f, 1.7f),
        "smirk" to "M9 16q3 1.500 6-1.500",
        "wavy" to "M8 16q1-1.500 2 0t2 0t2 0t2 0",
        "tongue" to "M8 14.5q4 4.5 8 0 M11 17.500v1.500a1 1 0 0 0 2 0v-1.500",
        "teeth" to "M7.500 14h9q0 4.500-4.500 4.500t-4.500-4.500z M7.500 16h9 M12 14v4.500",
        "tiny" to "M10 15.500q2 1.500 4 0",
        "sad" to "M10 16.500q2-1.500 4 0",
        "zigzag" to "M8 16l1.500-1.500 1.500 1.500 1.500-1.500 1.500 1.500 1.500-1.500 1.500 1.500"
    )

    private val extras = listOf(
        "" to "",
        "angry" to "M6.500 6.500l3.500 1.500 M17.500 6.500l-3.500 1.500",
        "raised" to "M7 6.500q1.500-1 3 0 M14 6.500q1.500-1 3 0",
        "tear" to "M8.500 13q-1 1.500 0 2.200q1-.700 0-2.200",
        "sweat" to "M20 5q-1.300 2 0 3q1.300-1 0-3",
        "blush" to "M5.500 12.500l1.500-1 M6.500 13.500l1.500-1 M18.500 12.500l-1.500-1 M17.500 13.500l-1.500-1"
    )

    val categories: List<IconCategory> = heads.map { (hid, title, headPath) ->
        val list = ArrayList<Ic>(extras.size * eyes.size * mouths.size)
        for ((xid, xd) in extras) {
            for ((eid, ed) in eyes) {
                for ((mid, md) in mouths) {
                    val id = "$hid.$xid.$eid.$mid"
                    list.add(Ic(id, "$headPath $ed $md $xd"))
                }
            }
        }
        IconCategory(hid, title, list)
    }
}

/** Значки интерфейса клавиатуры — тоже нарисованы линиями. */
object Ui {
    val face = Ic("ui_face", c(12f, 12f, 9f) + "M8.500 9.500v.01 M15.500 9.500v.01 M8 14.500q4 4.500 8 0")
    val clip = Ic("ui_clip", "M6 4.500h12v16H6z M9.500 4.500V3h5v1.500 M9 10h6 M9 13.500h6 M9 17h3")
    val lock = Ic("ui_lock", "M6 11h12v9H6z M8.500 11V8a3.500 3.500 0 0 1 7 0v3 M12 14.500v2")
    val gear = Ic(
        "ui_gear",
        c(12f, 12f, 3f) + "M12 2.500v3 M12 18.500v3 M2.500 12h3 M18.500 12h3 M5.300 5.300l2.100 2.100 M16.600 16.600l2.100 2.100 M18.700 5.300l-2.100 2.100 M7.400 16.600l-2.100 2.100 " + c(12f, 12f, 6.500f)
    )
    val edit = Ic("ui_edit", "M4 20l1-4L16 5l3 3L8 19z M14 7l3 3")
    val globe = Ic("ui_globe", c(12f, 12f, 9f) + "M3 12h18 M12 3c-4 4-4 14 0 18 M12 3c4 4 4 14 0 18")
    val shift = Ic("ui_shift", "M12 4l8 9h-5v7H9v-7H4z")
    val shiftCaps = Ic("ui_shift_caps", "M12 4l8 9h-5v7H9v-7H4z M9 22.500h6")
    val back = Ic("ui_back", "M20 6H9L3 12l6 6h11z M12 9.500l5 5 M17 9.500l-5 5")
    val enter = Ic("ui_enter", "M20 5v8H6 M10 9l-4 4 4 4")
    val trash = Ic("ui_trash", "M5 7h14 M9 7V4.500h6V7 M7 7l1 13h8l1-13 M10.500 11v6 M13.500 11v6")
    val close = Ic("ui_close", "M6 6l12 12 M18 6L6 18")
    val incognito = Ic("ui_incognito", "M3 11h18 M5.500 11l1.500-6h10l1.500 6 " + c(8f, 16f, 2.500f) + c(16f, 16f, 2.500f) + "M10.500 16h3")
}

object Registry {
    val byId: Map<String, Ic> by lazy {
        val m = HashMap<String, Ic>()
        for (cat in Faces.categories) for (i in cat.icons) m[i.id] = i
        for (cat in Objects.all) for (i in cat.icons) m[i.id] = i
        m
    }

    /** Все категории по порядку: сначала предметные, потом лица. */
    val categories: List<IconCategory> by lazy {
        Objects.all + Faces.categories
    }
}
