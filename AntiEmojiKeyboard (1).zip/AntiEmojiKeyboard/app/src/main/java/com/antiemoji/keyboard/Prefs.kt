package com.antiemoji.keyboard

import android.content.Context
import android.content.SharedPreferences
import java.io.File

class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("anti_emoji_kb", Context.MODE_PRIVATE)

    var bgAlpha: Int
        get() = sp.getInt("bgAlpha", 255)
        set(v) = sp.edit().putInt("bgAlpha", v).apply()

    var keyAlpha: Int
        get() = sp.getInt("keyAlpha", 255)
        set(v) = sp.edit().putInt("keyAlpha", v).apply()

    /** Высота рядов клавиш в dp. */
    var keyHeightDp: Int
        get() = sp.getInt("keyHeightDp", 50)
        set(v) = sp.edit().putInt("keyHeightDp", v).apply()

    var keyColor: Int
        get() = sp.getInt("keyColor", 0xFF2E2E2E.toInt())
        set(v) = sp.edit().putInt("keyColor", v).apply()

    var showNumberRow: Boolean
        get() = sp.getBoolean("showNumberRow", true)
        set(v) = sp.edit().putBoolean("showNumberRow", v).apply()

    var showToolbar: Boolean
        get() = sp.getBoolean("showToolbar", true)
        set(v) = sp.edit().putBoolean("showToolbar", v).apply()

    var showKeyBorders: Boolean
        get() = sp.getBoolean("showKeyBorders", true)
        set(v) = sp.edit().putBoolean("showKeyBorders", v).apply()

    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) = sp.edit().putBoolean("vibrate", v).apply()

    var incognito: Boolean
        get() = sp.getBoolean("incognito", false)
        set(v) = sp.edit().putBoolean("incognito", v).apply()

    /** true: иконки отправляются картинкой (видят все), false: текстовым кодом. */
    var sendAsImage: Boolean
        get() = sp.getBoolean("sendAsImage", true)
        set(v) = sp.edit().putBoolean("sendAsImage", v).apply()

    var lang: String
        get() = sp.getString("lang", "ru") ?: "ru"
        set(v) = sp.edit().putString("lang", v).apply()

    var hiddenKeys: Set<String>
        get() = HashSet(sp.getStringSet("hiddenKeys", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("hiddenKeys", HashSet(v)).apply()

    /** Секретные фразы: по строке "название=текст". */
    var secrets: String
        get() = sp.getString("secrets", "") ?: ""
        set(v) = sp.edit().putString("secrets", v).apply()

    fun secretList(): List<Pair<String, String>> =
        secrets.lines().mapNotNull { line ->
            val i = line.indexOf('=')
            if (i <= 0) null else Pair(line.substring(0, i).trim(), line.substring(i + 1))
        }

    var recent: List<String>
        get() = (sp.getString("recent", "") ?: "").split(',').filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("recent", v.joinToString(",")).apply()

    fun pushRecent(id: String) {
        val list = ArrayList(recent)
        list.remove(id)
        list.add(0, id)
        while (list.size > 40) list.removeAt(list.size - 1)
        recent = list
    }
}

/** Буфер обмена без ограничений по количеству: хранится в файле, одна запись на строку. */
class ClipStore(context: Context) {
    private val file = File(context.applicationContext.filesDir, "clipboard.txt")
    private val items = ArrayList<String>()
    private var loaded = false

    private fun enc(s: String) = s.replace("\\", "\\\\").replace("\n", "\\n")
    private fun dec(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                val n = s[i + 1]
                sb.append(if (n == 'n') '\n' else n)
                i += 2
            } else {
                sb.append(ch)
                i++
            }
        }
        return sb.toString()
    }

    @Synchronized
    private fun load() {
        if (loaded) return
        loaded = true
        if (file.exists()) {
            try {
                file.forEachLine { if (it.isNotEmpty()) items.add(dec(it)) }
            } catch (e: Exception) {
            }
        }
    }

    /** Новые записи сверху. */
    @Synchronized
    fun all(): List<String> {
        load()
        return items.asReversed().toList()
    }

    @Synchronized
    fun count(): Int {
        load()
        return items.size
    }

    @Synchronized
    fun add(text: String) {
        load()
        if (text.isBlank()) return
        if (items.isNotEmpty() && items[items.size - 1] == text) return
        items.add(text)
        try {
            file.appendText(enc(text) + "\n")
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun remove(text: String) {
        load()
        items.remove(text)
        rewrite()
    }

    @Synchronized
    fun clear() {
        load()
        items.clear()
        rewrite()
    }

    private fun rewrite() {
        try {
            file.writeText(items.joinToString("") { enc(it) + "\n" })
        } catch (e: Exception) {
        }
    }
}
