package com.antiemoji.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

interface KeyboardListener {
    fun onText(s: String)
    fun onDelete()
    fun onEnter()
    fun onIcon(ic: Ic)
    fun onOpenSettings()
}

enum class Mode { KEYS, SYMS, ICONS, CLIP, SECRETS }

class KeyboardView(
    context: Context,
    private val prefs: Prefs,
    private val clip: ClipStore,
    private val listener: KeyboardListener
) : View(context) {

    private class KRect(val key: Key, val r: RectF)
    private class BtnRect(val id: String, val r: RectF)

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val handler = Handler(Looper.getMainLooper())
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.WHITE }

    private var mode = Mode.KEYS
    private var lang = prefs.lang
    private var shift = 0
    private var lastShiftTap = 0L
    private var editMode = false

    private var rects = ArrayList<KRect>()
    private var toolbar = ArrayList<BtnRect>()
    private var bottomBtns = ArrayList<KRect>()

    // нажатие
    private var pressed: KRect? = null
    private var popupAlts: List<String> = emptyList()
    private var popupRects: List<RectF> = emptyList()
    private var popupSel = -1
    private var popupOpen = false
    private var longPress: Runnable? = null
    private var repeatDel: Runnable? = null

    // панели
    private var tab = 0
    private var tabScroll = 0f
    private var scrollY = 0f
    private var listItems: List<String> = emptyList()
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var downInTabs = false
    private val slop = 8f * density

    private fun toolbarH() = if (prefs.showToolbar) dp(44f) else 0f
    private fun rowH() = dp(prefs.keyHeightDp.toFloat())
    private fun rowsCount() = if (prefs.showNumberRow) 5 else 4
    private fun pad() = dp(6f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (toolbarH() + rowsCount() * rowH() + pad() * 2).toInt()
        setMeasuredDimension(w, h)
    }

    fun reloadPrefs() {
        lang = prefs.lang
        requestLayout()
        invalidate()
    }

    fun refreshLists() {
        if (mode == Mode.CLIP) listItems = clip.all()
        if (mode == Mode.SECRETS) listItems = prefs.secretList().map { it.first }
        invalidate()
    }

    // ---------- раскладка ----------

    private fun rebuild() {
        rects = ArrayList()
        toolbar = ArrayList()
        bottomBtns = ArrayList()
        val w = width.toFloat()
        val tb = toolbarH()
        val rh = rowH()
        val gap = dp(3f)

        if (tb > 0f) {
            val ids = listOf("face", "clip", "lock", "edit", "gear")
            val bw = dp(44f)
            val step = w / ids.size
            for ((i, id) in ids.withIndex()) {
                val cx = step * i + step / 2
                toolbar.add(BtnRect(id, RectF(cx - bw / 2, dp(2f), cx + bw / 2, tb - dp(2f))))
            }
        }

        var top = tb + pad()
        val hidden = prefs.hiddenKeys

        if (mode == Mode.KEYS || mode == Mode.SYMS) {
            val rows = ArrayList<List<Key>>()
            if (prefs.showNumberRow) rows.add(Layouts.numberRow())
            if (mode == Mode.KEYS) rows.addAll(Layouts.letterRows(lang)) else rows.addAll(Layouts.symbolRows())
            rows.add(if (mode == Mode.KEYS) Layouts.bottomRow(lang) else Layouts.symbolBottom())
            for (row in rows) {
                val visible = row.filter { editMode || !(it.hideable && hidden.contains(it.id)) }
                layoutRow(visible, top, rh, w, gap, rects)
                top += rh
            }
        } else {
            // нижняя панель: АБВ ... стереть
            val bottomTop = tb + pad() + (rowsCount() - 1) * rh
            val abc = Key("АБВ", Act.ABC, 1.3f)
            val del = Key("del", Act.DEL, 1.3f)
            val list = ArrayList<KRect>()
            layoutRow(listOf(abc, Key("", Act.CHAR, 5.5f), del), bottomTop, rh, w, gap, list)
            bottomBtns = list
        }
    }

    private fun layoutRow(keys: List<Key>, top: Float, rh: Float, w: Float, gap: Float, out: ArrayList<KRect>) {
        val total = keys.sumOf { it.weight.toDouble() }.toFloat()
        if (total <= 0f) return
        val usable = w - gap * 2
        var x = gap
        for (k in keys) {
            val kw = usable * (k.weight / total)
            out.add(KRect(k, RectF(x + gap / 2, top + gap / 2, x + kw - gap / 2, top + rh - gap / 2)))
            x += kw
        }
    }

    // ---------- рисование ----------

    override fun onDraw(canvas: Canvas) {
        rebuild()
        canvas.drawColor(Color.argb(prefs.bgAlpha, 14, 14, 14))
        drawToolbar(canvas)
        when (mode) {
            Mode.KEYS, Mode.SYMS -> {
                for (kr in rects) drawKey(canvas, kr)
                if (popupOpen) drawPopup(canvas)
            }
            Mode.ICONS -> drawIcons(canvas)
            Mode.CLIP, Mode.SECRETS -> drawList(canvas)
        }
        if (mode == Mode.ICONS || mode == Mode.CLIP || mode == Mode.SECRETS) {
            for (kr in bottomBtns) if (kr.key.label.isNotEmpty() || kr.key.act == Act.DEL) drawKey(canvas, kr)
        }
    }

    private fun keyFill(special: Boolean, down: Boolean): Int {
        val base = prefs.keyColor
        var r = Color.red(base)
        var g = Color.green(base)
        var b = Color.blue(base)
        if (special) {
            r = (r * 0.6f).toInt(); g = (g * 0.6f).toInt(); b = (b * 0.6f).toInt()
        }
        if (down) {
            r = min(255, r + 40); g = min(255, g + 40); b = min(255, b + 40)
        }
        return Color.argb(prefs.keyAlpha, r, g, b)
    }

    private fun drawToolbar(canvas: Canvas) {
        for (b in toolbar) {
            val active = (b.id == "face" && mode == Mode.ICONS) ||
                (b.id == "clip" && mode == Mode.CLIP) ||
                (b.id == "lock" && mode == Mode.SECRETS) ||
                (b.id == "edit" && editMode)
            fill.color = keyFill(false, false)
            val cx = b.r.centerX()
            val cy = b.r.centerY()
            val rad = min(b.r.width(), b.r.height()) / 2
            canvas.drawCircle(cx, cy, rad, fill)
            if (active) {
                stroke.color = Color.WHITE
                stroke.strokeWidth = dp(1.5f)
                canvas.drawCircle(cx, cy, rad, stroke)
            }
            val ic = when (b.id) {
                "face" -> Ui.face
                "clip" -> Ui.clip
                "lock" -> if (prefs.incognito) Ui.incognito else Ui.lock
                "edit" -> Ui.edit
                else -> Ui.gear
            }
            val s = rad * 1.15f
            IconRenderer.draw(canvas, ic, cx - s / 2, cy - s / 2, s, Color.WHITE)
        }
    }

    private fun drawKey(canvas: Canvas, kr: KRect) {
        val k = kr.key
        val r = kr.r
        val rad = dp(8f)
        val ghost = editMode && k.hideable && prefs.hiddenKeys.contains(k.id)
        val special = k.act != Act.CHAR && k.act != Act.SPACE
        val down = pressed === kr && !popupOpen

        if (ghost) {
            stroke.color = Color.argb(140, 255, 255, 255)
            stroke.strokeWidth = dp(1f)
            stroke.pathEffect = DashPathEffect(floatArrayOf(dp(4f), dp(4f)), 0f)
            canvas.drawRoundRect(r, rad, rad, stroke)
            stroke.pathEffect = null
        } else {
            fill.color = keyFill(special, down)
            canvas.drawRoundRect(r, rad, rad, fill)
            if (prefs.showKeyBorders) {
                stroke.color = Color.argb(60, 255, 255, 255)
                stroke.strokeWidth = dp(0.8f)
                canvas.drawRoundRect(r, rad, rad, stroke)
            }
        }
        if (editMode && k.hideable && !ghost) {
            stroke.color = Color.argb(200, 255, 255, 255)
            stroke.strokeWidth = dp(1f)
            stroke.pathEffect = DashPathEffect(floatArrayOf(dp(3f), dp(3f)), 0f)
            canvas.drawRoundRect(r, rad, rad, stroke)
            stroke.pathEffect = null
        }

        val cx = r.centerX()
        val cy = r.centerY()
        val iconSize = min(r.height() * 0.5f, dp(26f))
        val alpha = if (ghost) 90 else 255
        val white = Color.argb(alpha, 255, 255, 255)

        when (k.act) {
            Act.SHIFT -> IconRenderer.draw(canvas, if (shift == 2) Ui.shiftCaps else Ui.shift, cx - iconSize / 2, cy - iconSize / 2, iconSize, if (shift > 0) Color.WHITE else Color.argb(190, 255, 255, 255), if (shift > 0) 2.2f else 1.6f)
            Act.DEL -> IconRenderer.draw(canvas, Ui.back, cx - iconSize / 2, cy - iconSize / 2, iconSize, white)
            Act.LANG -> IconRenderer.draw(canvas, Ui.globe, cx - iconSize / 2, cy - iconSize / 2, iconSize, white)
            Act.ENTER -> IconRenderer.draw(canvas, Ui.enter, cx - iconSize / 2, cy - iconSize / 2, iconSize, white)
            Act.SPACE -> {
                text.color = Color.argb(200, 255, 255, 255)
                text.textSize = min(r.height() * 0.32f, dp(15f))
                drawCentered(canvas, k.label, cx, cy)
            }
            else -> {
                if (k.label.isEmpty()) return
                text.color = white
                val isLetter = k.id.contains(':')
                val shown = if (isLetter && shift == 0) k.label else k.label
                text.textSize = if (k.act == Act.CHAR) r.height() * 0.46f else r.height() * 0.32f
                drawCentered(canvas, shown, cx, cy)
                if (k.alts.isNotEmpty() && k.alts[0].length == 1 && k.alts[0][0].isDigit() && k.act == Act.CHAR && isLetter) {
                    text.color = Color.argb(alpha / 2, 255, 255, 255)
                    text.textSize = r.height() * 0.24f
                    drawCentered(canvas, k.alts[0], r.right - dp(8f), r.top + r.height() * 0.24f)
                }
                if (k.act == Act.CHAR && k.id.contains(':') && (k.alts.contains("ё") || k.alts.contains("ъ"))) {
                    text.color = Color.argb(alpha / 2, 255, 255, 255)
                    text.textSize = r.height() * 0.24f
                    val hint = if (k.alts.contains("ё")) "Ё" else "Ъ"
                    drawCentered(canvas, hint, r.right - dp(8f), r.top + r.height() * 0.24f)
                }
            }
        }
    }

    private fun drawCentered(canvas: Canvas, s: String, cx: Float, cy: Float) {
        val fm = text.fontMetrics
        canvas.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2, text)
    }

    private fun drawPopup(canvas: Canvas) {
        val kr = pressed ?: return
        for ((i, r) in popupRects.withIndex()) {
            fill.color = if (i == popupSel) Color.WHITE else Color.argb(255, 60, 60, 60)
            canvas.drawRoundRect(r, dp(8f), dp(8f), fill)
            text.color = if (i == popupSel) Color.BLACK else Color.WHITE
            text.textSize = r.height() * 0.5f
            drawCentered(canvas, popupAlts[i], r.centerX(), r.centerY())
        }
        if (popupRects.isEmpty()) return
        val top = popupRects[0].top
        stroke.color = Color.argb(120, 255, 255, 255)
        stroke.strokeWidth = dp(1f)
        canvas.drawLine(kr.r.centerX(), kr.r.top, kr.r.centerX(), top + popupRects[0].height(), stroke)
    }

    // ---------- панель иконок ----------

    private fun tabNames(): List<String> = listOf("Недавние") + Registry.categories.map { it.title }

    private fun tabWidths(): List<Float> {
        text.textSize = dp(14f)
        return tabNames().map { text.measureText(it) + dp(26f) }
    }

    private fun currentIcons(): List<Ic> {
        if (tab == 0) return prefs.recent.mapNotNull { Registry.byId[it] }
        val cats = Registry.categories
        return if (tab - 1 in cats.indices) cats[tab - 1].icons else emptyList()
    }

    private fun contentTop() = toolbarH() + pad()
    private fun contentBottom() = toolbarH() + pad() + (rowsCount() - 1) * rowH()
    private fun tabBarH() = dp(38f)
    private fun cell() = dp(46f)
    private fun cols() = max(1, (width / cell()).toInt())

    private fun clampScroll(total: Float, area: Float) {
        scrollY = max(0f, min(scrollY, max(0f, total - area)))
    }

    private fun drawIcons(canvas: Canvas) {
        val top = contentTop()
        val tbh = tabBarH()
        val widths = tabWidths()
        // вкладки
        canvas.save()
        canvas.clipRect(0f, top, width.toFloat(), top + tbh)
        var x = -tabScroll
        for ((i, name) in tabNames().withIndex()) {
            val w = widths[i]
            if (i == tab) {
                fill.color = Color.argb(255, 70, 70, 70)
                canvas.drawRoundRect(RectF(x + dp(2f), top + dp(3f), x + w - dp(2f), top + tbh - dp(3f)), dp(14f), dp(14f), fill)
            }
            text.color = if (i == tab) Color.WHITE else Color.argb(170, 255, 255, 255)
            text.textSize = dp(14f)
            drawCentered(canvas, name, x + w / 2, top + tbh / 2)
            x += w
        }
        canvas.restore()

        // сетка
        val gTop = top + tbh
        val gBottom = contentBottom()
        val list = currentIcons()
        val cols = cols()
        val cell = cell()
        val rowsN = (list.size + cols - 1) / cols
        clampScroll(rowsN * cell, gBottom - gTop)
        canvas.save()
        canvas.clipRect(0f, gTop, width.toFloat(), gBottom)
        if (list.isEmpty()) {
            text.color = Color.argb(150, 255, 255, 255)
            text.textSize = dp(14f)
            drawCentered(canvas, "Здесь появятся последние иконки", width / 2f, (gTop + gBottom) / 2)
        }
        val firstRow = max(0, (scrollY / cell).toInt())
        val lastRow = min(rowsN - 1, ((scrollY + gBottom - gTop) / cell).toInt())
        val left = (width - cols * cell) / 2
        val size = cell * 0.68f
        for (row in firstRow..lastRow) {
            for (col in 0 until cols) {
                val idx = row * cols + col
                if (idx >= list.size) break
                val ix = left + col * cell + (cell - size) / 2
                val iy = gTop + row * cell - scrollY + (cell - size) / 2
                IconRenderer.draw(canvas, list[idx], ix, iy, size, Color.WHITE)
            }
        }
        canvas.restore()
    }

    // ---------- списки (буфер, секреты) ----------

    private fun itemH() = dp(46f)
    private fun listHeaderH() = dp(40f)

    private fun drawList(canvas: Canvas) {
        val top = contentTop()
        val hh = listHeaderH()
        text.textSize = dp(14f)
        text.color = Color.argb(220, 255, 255, 255)
        text.textAlign = Paint.Align.LEFT
        val fm = text.fontMetrics
        val headerY = top + hh / 2 - (fm.ascent + fm.descent) / 2
        if (mode == Mode.CLIP) {
            canvas.drawText("Буфер обмена: ${clip.count()}", dp(14f), headerY, text)
            text.textAlign = Paint.Align.RIGHT
            canvas.drawText("Очистить всё", width - dp(14f), headerY, text)
        } else {
            val state = if (prefs.incognito) "вкл" else "выкл"
            canvas.drawText("Секреты  ·  инкогнито: $state (нажми здесь)", dp(14f), headerY, text)
        }
        text.textAlign = Paint.Align.CENTER

        val lTop = top + hh
        val lBottom = contentBottom()
        val ih = itemH()
        clampScroll(listItems.size * ih, lBottom - lTop)
        canvas.save()
        canvas.clipRect(0f, lTop, width.toFloat(), lBottom)
        if (listItems.isEmpty()) {
            text.color = Color.argb(150, 255, 255, 255)
            text.textSize = dp(14f)
            val msg = if (mode == Mode.CLIP) "Пока пусто. Скопируй что-нибудь." else "Добавь секретные фразы в настройках"
            drawCentered(canvas, msg, width / 2f, (lTop + lBottom) / 2)
        }
        val first = max(0, (scrollY / ih).toInt())
        val last = min(listItems.size - 1, ((scrollY + lBottom - lTop) / ih).toInt())
        for (i in first..last) {
            val y = lTop + i * ih - scrollY
            val rr = RectF(dp(6f), y + dp(2f), width - dp(6f), y + ih - dp(2f))
            fill.color = keyFill(false, false)
            canvas.drawRoundRect(rr, dp(8f), dp(8f), fill)
            var s = if (mode == Mode.SECRETS) "• ".plus(listItems[i]) else listItems[i].replace('\n', ' ')
            val maxW = rr.width() - dp(60f)
            text.textAlign = Paint.Align.LEFT
            text.textSize = dp(15f)
            text.color = Color.WHITE
            val n = text.breakText(s, true, maxW, null)
            if (n < s.length) s = s.substring(0, max(0, n - 1)) + "…"
            val fm2 = text.fontMetrics
            canvas.drawText(s, rr.left + dp(12f), rr.centerY() - (fm2.ascent + fm2.descent) / 2, text)
            text.textAlign = Paint.Align.CENTER
            if (mode == Mode.CLIP) {
                val sz = dp(18f)
                IconRenderer.draw(canvas, Ui.close, rr.right - dp(26f) - sz / 2 + dp(9f), rr.centerY() - sz / 2, sz, Color.argb(170, 255, 255, 255))
            }
        }
        canvas.restore()
    }

    // ---------- касания ----------

    private fun haptic() {
        if (prefs.vibrate) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun findKey(x: Float, y: Float, list: List<KRect>): KRect? {
        // сначала точное попадание, потом ближайшая по горизонтали в той же строке
        for (kr in list) if (kr.r.contains(x, y)) return kr
        var best: KRect? = null
        var bestD = Float.MAX_VALUE
        for (kr in list) {
            val inRow = y >= kr.r.top - dp(3f) && y <= kr.r.bottom + dp(3f)
            if (!inRow) continue
            val d = abs(kr.r.centerX() - x)
            if (d < bestD) { bestD = d; best = kr }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; moved = false
                // панель инструментов
                for (b in toolbar) if (b.r.contains(e.x, e.y)) { haptic(); onToolbar(b.id); downInTabs = false; pressed = null; return true }
                val list = if (mode == Mode.KEYS || mode == Mode.SYMS) rects else bottomBtns
                val kr = findKey(e.x, e.y, list)
                if (kr != null && (mode == Mode.KEYS || mode == Mode.SYMS || kr.r.contains(e.x, e.y))) {
                    pressed = kr
                    haptic()
                    onKeyDown(kr)
                    invalidate()
                    return true
                }
                pressed = null
                downInTabs = mode == Mode.ICONS && e.y >= contentTop() && e.y <= contentTop() + tabBarH()
            }
            MotionEvent.ACTION_MOVE -> {
                val kr = pressed
                if (kr != null) {
                    if (popupOpen) {
                        var sel = -1
                        for ((i, r) in popupRects.withIndex()) if (e.x >= r.left && e.x <= r.right) sel = i
                        if (sel != popupSel) { popupSel = sel; invalidate() }
                    } else if (abs(e.y - downY) > rowH() * 1.6f || abs(e.x - downX) > rowH() * 2.5f) {
                        cancelPress()
                    }
                    return true
                }
                if (abs(e.x - downX) > slop || abs(e.y - downY) > slop) moved = true
                if (moved) {
                    if (downInTabs) tabScroll = max(0f, tabScroll - (e.x - lastX)) else scrollY -= (e.y - lastY)
                    invalidate()
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                val kr = pressed
                if (kr != null) {
                    onKeyUp(kr)
                    cancelPress()
                    return true
                }
                if (!moved) onPanelTap(e.x, e.y)
            }
            MotionEvent.ACTION_CANCEL -> cancelPress()
        }
        return true
    }

    private fun cancelPress() {
        longPress?.let { handler.removeCallbacks(it) }
        repeatDel?.let { handler.removeCallbacks(it) }
        longPress = null
        repeatDel = null
        pressed = null
        popupOpen = false
        popupSel = -1
        invalidate()
    }

    private fun onKeyDown(kr: KRect) {
        val k = kr.key
        if (editMode) return
        if (k.act == Act.DEL) {
            listener.onDelete()
            val rep = object : Runnable {
                override fun run() {
                    listener.onDelete()
                    handler.postDelayed(this, 45)
                }
            }
            repeatDel = rep
            handler.postDelayed(rep, 400)
            return
        }
        if (k.alts.isNotEmpty() && k.act == Act.CHAR) {
            val lp = Runnable { openPopup(kr) }
            longPress = lp
            handler.postDelayed(lp, 330)
        }
        if (k.act == Act.SPACE) {
            val lp = Runnable {
                // долгое нажатие на пробел открывает секреты
                haptic()
                cancelPress()
                switchMode(Mode.SECRETS)
            }
            longPress = lp
            handler.postDelayed(lp, 600)
        }
    }

    private fun openPopup(kr: KRect) {
        val alts = kr.key.alts.map { if (shift > 0) it.uppercase() else it }
        if (alts.isEmpty()) return
        popupAlts = alts
        val cw = max(kr.r.width(), dp(42f))
        val total = cw * alts.size
        var left = kr.r.centerX() - total / 2
        left = max(dp(2f), min(left, width - total - dp(2f)))
        val h = kr.r.height()
        val top = max(0f, kr.r.top - h - dp(6f))
        val list = ArrayList<RectF>()
        for (i in alts.indices) list.add(RectF(left + i * cw, top, left + (i + 1) * cw, top + h))
        popupRects = list
        popupSel = 0
        popupOpen = true
        haptic()
        invalidate()
    }

    private fun onKeyUp(kr: KRect) {
        val k = kr.key
        if (editMode) {
            if (k.hideable) {
                val set = prefs.hiddenKeys.toMutableSet()
                if (!set.remove(k.id)) set.add(k.id)
                prefs.hiddenKeys = set
            }
            return
        }
        if (popupOpen) {
            if (popupSel in popupAlts.indices) typed(popupAlts[popupSel])
            return
        }
        when (k.act) {
            Act.DEL -> {}
            Act.CHAR -> {
                if (k.id.contains(':')) {
                    typed(if (shift > 0) k.label.uppercase() else k.label.lowercase())
                } else typed(k.label)
            }
            Act.SPACE -> listener.onText(" ")
            Act.ENTER -> listener.onEnter()
            Act.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (shift == 2) 0 else if (now - lastShiftTap < 350 && shift == 1) 2 else if (shift == 1) 0 else 1
                lastShiftTap = now
            }
            Act.SYMS -> switchMode(Mode.SYMS)
            Act.ABC -> switchMode(Mode.KEYS)
            Act.LANG -> {
                lang = if (lang == "ru") "en" else "ru"
                prefs.lang = lang
            }
        }
        invalidate()
    }

    private fun typed(s: String) {
        listener.onText(s)
        if (shift == 1) shift = 0
    }

    private fun switchMode(m: Mode) {
        mode = m
        scrollY = 0f
        popupOpen = false
        if (m == Mode.CLIP) listItems = clip.all()
        if (m == Mode.SECRETS) listItems = prefs.secretList().map { it.first }
        invalidate()
    }

    private fun onToolbar(id: String) {
        when (id) {
            "face" -> switchMode(if (mode == Mode.ICONS) Mode.KEYS else Mode.ICONS)
            "clip" -> switchMode(if (mode == Mode.CLIP) Mode.KEYS else Mode.CLIP)
            "lock" -> switchMode(if (mode == Mode.SECRETS) Mode.KEYS else Mode.SECRETS)
            "edit" -> {
                editMode = !editMode
                if (editMode) switchMode(Mode.KEYS)
                invalidate()
            }
            "gear" -> listener.onOpenSettings()
        }
    }

    private fun onPanelTap(x: Float, y: Float) {
        when (mode) {
            Mode.ICONS -> {
                val top = contentTop()
                if (y < top) return
                if (y <= top + tabBarH()) {
                    var px = -tabScroll
                    for ((i, w) in tabWidths().withIndex()) {
                        if (x >= px && x < px + w) { tab = i; scrollY = 0f; invalidate(); return }
                        px += w
                    }
                    return
                }
                val gTop = top + tabBarH()
                if (y > contentBottom()) return
                val cell = cell()
                val cols = cols()
                val left = (width - cols * cell) / 2
                val col = ((x - left) / cell).toInt()
                if (col < 0 || col >= cols) return
                val row = ((y - gTop + scrollY) / cell).toInt()
                val idx = row * cols + col
                val list = currentIcons()
                if (idx in list.indices) {
                    haptic()
                    prefs.pushRecent(list[idx].id)
                    listener.onIcon(list[idx])
                }
            }
            Mode.CLIP, Mode.SECRETS -> {
                val top = contentTop()
                if (y < top) return
                if (y <= top + listHeaderH()) {
                    if (mode == Mode.CLIP) {
                        if (x > width - dp(130f)) { clip.clear(); listItems = emptyList(); invalidate() }
                    } else {
                        prefs.incognito = !prefs.incognito
                        invalidate()
                    }
                    return
                }
                if (y > contentBottom()) return
                val idx = ((y - top - listHeaderH() + scrollY) / itemH()).toInt()
                if (idx !in listItems.indices) return
                if (mode == Mode.CLIP) {
                    if (x > width - dp(52f)) {
                        clip.remove(listItems[idx])
                        listItems = clip.all()
                        invalidate()
                    } else {
                        haptic()
                        listener.onText(listItems[idx])
                    }
                } else {
                    val name = listItems[idx]
                    val value = prefs.secretList().firstOrNull { it.first == name }?.second ?: return
                    haptic()
                    listener.onText(value)
                }
            }
            else -> {}
        }
    }
}
