package com.antiemoji.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var clip: ClipStore
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        clip = ClipStore(this)

        val scroll = ScrollView(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(24), dp(18), dp(40))
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)

        title("Анти-эмодзи")
        body("Клавиатура без настоящих эмодзи: вместо них нарисованные линиями значки. Всё работает без интернета.")

        section("Подключение")
        button("1. Включить клавиатуру в системе") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        button("2. Сделать основной клавиатурой") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        val test = EditText(this)
        test.hint = "Сюда можно нажать и проверить клавиатуру"
        test.setHintTextColor(Color.GRAY)
        test.setTextColor(Color.WHITE)
        root.addView(test, lp(top = 10))

        section("Вид")
        slider("Прозрачность фона", 0, 255, prefs.bgAlpha) { prefs.bgAlpha = it }
        slider("Прозрачность клавиш", 0, 255, prefs.keyAlpha) { prefs.keyAlpha = it }
        slider("Высота клавиш", 36, 72, prefs.keyHeightDp) { prefs.keyHeightDp = it }
        body("Цвет клавиш")
        val colors = LinearLayout(this)
        colors.orientation = LinearLayout.HORIZONTAL
        val palette = listOf(
            0xFF2E2E2E.toInt(), 0xFF000000.toInt(), 0xFF3A3A5C.toInt(),
            0xFF2F4F3A.toInt(), 0xFF5C3A3A.toInt(), 0xFFFFFFFF.toInt()
        )
        for (col in palette) {
            val b = Button(this)
            b.setBackgroundColor(col)
            b.setOnClickListener { prefs.keyColor = col; Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show() }
            val p = LinearLayout.LayoutParams(0, dp(40), 1f)
            p.setMargins(dp(3), dp(4), dp(3), dp(4))
            colors.addView(b, p)
        }
        root.addView(colors)
        toggle("Ряд цифр сверху", prefs.showNumberRow) { prefs.showNumberRow = it }
        toggle("Верхняя панель (смайлы, буфер, настройки)", prefs.showToolbar) { prefs.showToolbar = it }
        toggle("Рамки у клавиш", prefs.showKeyBorders) { prefs.showKeyBorders = it }
        toggle("Вибрация", prefs.vibrate) { prefs.vibrate = it }

        section("Иконки")
        toggle("Отправлять иконки картинкой (их увидят все)", prefs.sendAsImage) { prefs.sendAsImage = it }
        body("Если приложение не принимает картинки из клавиатуры, вставится текстовый код вида [heart].")

        section("Кнопки")
        body("На клавиатуре нажми значок карандаша: кнопки станут пунктирными. Нажатие на кнопку скрывает её, повторное возвращает.")
        button("Вернуть все скрытые кнопки (${prefs.hiddenKeys.size})") {
            prefs.hiddenKeys = emptySet()
            Toast.makeText(this, "Все кнопки вернулись", Toast.LENGTH_SHORT).show()
        }
        body("Зажми любую букву, чтобы выбрать цифру или странный символ. Зажми пробел, чтобы открыть секреты.")

        section("Буфер обмена")
        body("Без ограничений по количеству. Сейчас записей: ${clip.count()}")
        button("Очистить буфер") {
            clip.clear()
            Toast.makeText(this, "Буфер очищен", Toast.LENGTH_SHORT).show()
        }
        toggle("Инкогнито (не запоминать копируемое)", prefs.incognito) { prefs.incognito = it }

        section("Секреты")
        body("Каждая строка: название=текст. Открываются замком на клавиатуре или долгим нажатием на пробел.")
        val sec = EditText(this)
        sec.setText(prefs.secrets)
        sec.setTextColor(Color.WHITE)
        sec.setHintTextColor(Color.GRAY)
        sec.hint = "почта=me@example.com"
        sec.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        sec.minLines = 4
        sec.gravity = Gravity.TOP
        sec.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.secrets = s?.toString() ?: ""
            }
        })
        root.addView(sec, lp(top = 6))
    }

    private fun lp(top: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(top)
        }

    private fun title(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 28f
        t.setTextColor(Color.WHITE)
        root.addView(t, lp())
    }

    private fun section(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 18f
        t.setTextColor(Color.WHITE)
        t.setPadding(0, dp(24), 0, dp(6))
        root.addView(t, lp())
    }

    private fun body(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 14f
        t.setTextColor(Color.parseColor("#B0B0B0"))
        t.setPadding(0, dp(4), 0, dp(4))
        root.addView(t, lp())
    }

    private fun button(s: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        root.addView(b, lp(top = 6))
    }

    private fun toggle(s: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = s
        sw.setTextColor(Color.WHITE)
        sw.isChecked = value
        sw.setPadding(0, dp(8), 0, dp(8))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        root.addView(sw, lp())
    }

    private fun slider(s: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit) {
        val t = TextView(this)
        t.text = s
        t.setTextColor(Color.WHITE)
        t.setPadding(0, dp(10), 0, 0)
        root.addView(t, lp())
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (value - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress + min)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        root.addView(sb, lp())
    }
}
