package com.antiemoji.keyboard

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.core.graphics.PathParser

object IconRenderer {

    private val cache = object : LinkedHashMap<String, Path>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Path>?): Boolean =
            size > 600
    }

    private fun pathOf(ic: Ic): Path {
        cache[ic.id]?.let { return it }
        val p: Path = try {
            PathParser.createPathFromPathData(ic.d) ?: Path()
        } catch (e: Throwable) {
            Path()
        }
        if (ic.rot != 0f || ic.flipY) {
            val m = Matrix()
            if (ic.flipY) m.postScale(1f, -1f, 12f, 12f)
            if (ic.rot != 0f) m.postRotate(ic.rot, 12f, 12f)
            p.transform(m)
        }
        cache[ic.id] = p
        return p
    }

    /** Рисует иконку в квадрате size x size с левым верхним углом (x, y). */
    fun draw(canvas: Canvas, ic: Ic, x: Float, y: Float, size: Float, color: Int, lineWidth: Float = 1.6f) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = color
        paint.strokeWidth = lineWidth
        val s = size / 24f
        canvas.save()
        canvas.translate(x, y)
        canvas.scale(s, s)
        canvas.drawPath(pathOf(ic), paint)
        canvas.restore()
    }

    /** PNG для отправки в чаты: белые линии на тёмной плашке, чтобы было видно на любом фоне. */
    fun toBitmap(ic: Ic, px: Int = 256): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.color = Color.parseColor("#1C1C1E")
        val r = px * 0.22f
        cv.drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, bg)
        val pad = px * 0.14f
        draw(cv, ic, pad, pad, px - 2 * pad, Color.WHITE, 1.5f)
        return bmp
    }
}
