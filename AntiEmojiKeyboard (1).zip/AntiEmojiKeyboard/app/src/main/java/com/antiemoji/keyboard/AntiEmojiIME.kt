package com.antiemoji.keyboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File
import java.io.FileOutputStream

class AntiEmojiIME : InputMethodService(), KeyboardListener {

    private lateinit var prefs: Prefs
    private lateinit var clip: ClipStore
    private var view: KeyboardView? = null
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        clip = ClipStore(this)
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val l = ClipboardManager.OnPrimaryClipChangedListener {
            try {
                if (!prefs.incognito) {
                    val c = cm.primaryClip
                    if (c != null && c.itemCount > 0) {
                        val t = c.getItemAt(0).coerceToText(this)?.toString()
                        if (!t.isNullOrBlank()) {
                            clip.add(t)
                            view?.refreshLists()
                        }
                    }
                }
            } catch (e: Exception) {
            }
        }
        clipListener = l
        cm.addPrimaryClipChangedListener(l)
    }

    override fun onDestroy() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipListener?.let { cm.removePrimaryClipChangedListener(it) }
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        try {
            window?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        } catch (e: Exception) {
        }
        val v = KeyboardView(this, prefs, clip, this)
        view = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        view?.reloadPrefs()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    // ---------- KeyboardListener ----------

    override fun onText(s: String) {
        if (s.isEmpty()) return
        currentInputConnection?.commitText(s, 1)
    }

    override fun onDelete() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    override fun onEnter() {
        val ei = currentInputEditorInfo
        val action = if (ei != null) ei.imeOptions and EditorInfo.IME_MASK_ACTION else EditorInfo.IME_ACTION_NONE
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei == null || noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            currentInputConnection?.performEditorAction(action)
        }
    }

    override fun onOpenSettings() {
        val i = Intent(this, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    override fun onIcon(ic: Ic) {
        if (prefs.sendAsImage && commitAsImage(ic)) return
        if (prefs.sendAsImage) {
            Toast.makeText(this, "Это приложение не принимает картинки, вставлен текстовый код", Toast.LENGTH_SHORT).show()
        }
        onText("[" + ic.id + "]")
    }

    private fun commitAsImage(ic: Ic): Boolean {
        val info = currentInputEditorInfo ?: return false
        val conn = currentInputConnection ?: return false
        val mimes = EditorInfoCompat.getContentMimeTypes(info)
        val ok = mimes.any { ClipDescription.compareMimeTypes("image/png", it) }
        if (!ok) return false
        return try {
            val dir = File(cacheDir, "icons")
            dir.mkdirs()
            val safe = ic.id.replace(Regex("[^A-Za-z0-9_]"), "_")
            val f = File(dir, "$safe.png")
            if (!f.exists()) {
                val bmp = IconRenderer.toBitmap(ic, 256)
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            val uri = FileProvider.getUriForFile(this, "com.antiemoji.keyboard.files", f)
            val content = InputContentInfoCompat(uri, ClipDescription(ic.id, arrayOf("image/png")), null)
            val flags = if (Build.VERSION.SDK_INT >= 25) InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION else 0
            InputConnectionCompat.commitContent(conn, info, content, flags, null)
        } catch (e: Exception) {
            false
        }
    }
}
